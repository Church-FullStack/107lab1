module.exports = {  //exports the functions within the module for use outside the file
    isEven: function(num){
        var res = num % 2;
        if(res == 0){
            return true;
        }
        else{
            return false;
        }
    },
    sum: function (num1, num2){
        return num1 + num2;
    },
    greater: function(num1, num2){
        if(num1 > num2){
            return num1;
        }
            return num2;
 
    },
    lesser: function(num1,num2){
        if(num1 < num2)
            return num1;
        
            return num2;
    },
    divide: function(num1, num2){
        if(num2 == 0){
            console.log("Error: Can't divide by Zero");
            return 0;
        }
        return num1 / num2;
    }

};
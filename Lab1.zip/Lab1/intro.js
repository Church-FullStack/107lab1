var evens = [];
var mathLib = require('./math'); //import module

function exc1(){
    for(let i = 1; i<=10; i++){
        if (i != 3 && i != 7){
            console.log(i);
        }
    }
}

function exc2(howMany){

        for(i = 0; i < howMany *2; i++){
            var res = i % 2; // % = modulo; remainder of a division, instead of the result.
            if(mathLib.isEven(i)){
                console.log("even" + i);
                evens.push(i);
                console.log(evens);
            }
        }
}
exc1();
exc2(10);
console.log(mathLib.greater(21, 25));
console.log(mathLib.lesser(22, 25));

var res = mathLib.divide(12,4);
var err = mathLib.divide(12,0);
console.log(res);
console.log(err);
